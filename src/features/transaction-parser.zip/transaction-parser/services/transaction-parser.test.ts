import { describe, it, expect } from 'vitest'
import { parsePdfTransactions } from './transaction-parser'
import type { ExtractedPdf, ExtractedPage, ExtractedTextItem } from '../../pdf-extraction/types/extracted-text'

function item(text: string, x: number, y: number): ExtractedTextItem {
  return {
    text,
    x,
    y,
    width: 80,
    height: 9,
    fontName: 'test-font',
    hasEOL: false,
  }
}

function createPdf(remarkItems: ExtractedTextItem[]): ExtractedPdf {
  const page: ExtractedPage = {
    pageNumber: 1,
    width: 595,
    height: 842,
    items: [
      item('01 Oct 2026,', 35, 700),
      ...remarkItems,
      item('100.00', 340, 695.34),
      item('0.00', 420, 695.34),
      item('900.00', 500, 695.34),
    ],
  }

  return {
    fileName: 'synthetic.pdf',
    totalPages: 1,
    pages: [page],
  }
}

describe('Transaction Parser', () => {
  it('extracts a recipient after KE and keeps the source remark', () => {
    const result = parsePdfTransactions(
      createPdf([
        item('MCM InhouseTrf KE', 120, 710),
        item('SHOLAHUDIN Transfer Fee', 120, 690),
      ]),
    )

    expect(result[0].name).toBe('SHOLAHUDIN')
    expect(result[0].description).toContain('MCM InhouseTrf KE')
    expect(result[0].sourceDebit).toBe(100)
    expect(result[0].sourceCredit).toBe(0)
    expect(result[0].balance).toBe(900)
  })

  it('extracts a sender after DARI', () => {
    const result = parsePdfTransactions(
      createPdf([
        item('DARI BAGUS SANTOSO balikin modal', 120, 710),
      ]),
    )

    expect(result[0].name).toBe('BAGUS SANTOSO')
  })

  it('uses the approved Ops Koperasi description', () => {
    const result = parsePdfTransactions(
      createPdf([
        item('MCM InhouseTrf KE', 120, 710),
        item('SHOLAHUDIN Transfer Fee koperasi', 120, 690),
      ]),
    )

    expect(result[0].description).toBe('Ops Koperasi')
    expect(result[0].name).toBe('SHOLAHUDIN')
  })

  it('leaves the name empty when no confirmed name marker exists', () => {
    const result = parsePdfTransactions(
      createPdf([item('Maintenance okt E', 120, 710)]),
    )

    expect(result[0].name).toBe('')
    expect(result[0].description).toBe('Maintenance okt E')
  })
})
